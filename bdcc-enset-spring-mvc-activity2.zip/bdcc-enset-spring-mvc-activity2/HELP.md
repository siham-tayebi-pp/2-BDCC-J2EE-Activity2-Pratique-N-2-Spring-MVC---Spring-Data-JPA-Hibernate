# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/3.5.13/maven-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/3.5.13/maven-plugin/build-image.html)
* [Spring Data JPA](https://docs.spring.io/spring-boot/3.5.13/reference/data/sql.html#data.sql.jpa-and-spring-data)
* [Spring Security](https://docs.spring.io/spring-boot/3.5.13/reference/web/spring-security.html)
* [Thymeleaf](https://docs.spring.io/spring-boot/3.5.13/reference/web/servlet.html#web.servlet.spring-mvc.template-engines)
* [Validation](https://docs.spring.io/spring-boot/3.5.13/reference/io/validation.html)
* [Spring Web](https://docs.spring.io/spring-boot/3.5.13/reference/web/servlet.html)

### Guides
The following guides illustrate how to use some features concretely:

* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)
* [Accessing data with MySQL](https://spring.io/guides/gs/accessing-data-mysql/)
* [Securing a Web Application](https://spring.io/guides/gs/securing-web/)
* [Spring Boot and OAuth2](https://spring.io/guides/tutorials/spring-boot-oauth2/)
* [Authenticating a User with LDAP](https://spring.io/guides/gs/authenticating-ldap/)
* [Handling Form Submission](https://spring.io/guides/gs/handling-form-submission/)
* [Validation](https://spring.io/guides/gs/validating-form-input/)
* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)

### Maven Parent overrides

![img_auth.png](images/img_auth.png)
![img_con_bd.png](images/img_con_bd.png)
![bd.png](images/bd.png)
Inject de dependansce soit avec autowired ou avec const snas args
![lst_avant_bootstrap.png](images/lst_avant_bootstrap.png)
![img_apres_bootstrap.png](images/img_apres_bootstrap.png)

![img_btn_delete.png](images/img_btn_delete.png)
![test_delete.png](images/test_delete.png)


![delete_confirmation.png](images/delete_confirmation.png)
![apres_delete.png](images/apres_delete.png)
Ajoutr dependance theaymlyf layout poru ajouter les layouts



Apres decorate products avec layout
![apres_layout.png](images/apres_layout.png)
![modif_navbar.png](images/modif_navbar.png)

On associe des href a cahue lien  / vers home et products vers liste de sproduits


AJouter page de new products

Bn nw product

On ajoute la route saveProduct


![liste_apres_ajout.png](images/liste_apres_ajout.png)

tst2
![test2.png](images/test2.png)
![liste_apres_ajout2.png](images/liste_apres_ajout2.png)


Partie 2: spring security
On aura besoin du depndance spring starter security
pour faire appel a spring securilty directement a partir de theeamlyf
on desactive securite 

On reexecute alpp et on voi il dmd dentrer les username et psswd car spring secruty integrr lauthntid dans chque operation
![activation_spring_security.png](images/activation_spring_security.png)
et ca marche
![ success.![success.png](images/success.png)png](images/activation_spring_security.png)

On passe a creer une classe de sec config
dans packege config
avec anot enable web sec et config pour activr sec web
si user pas authentf il affiche le sien sinn fl -> login etc et tt req necessite une authentif 
on ajoute une meth bcrypt pur hasher le mdp
![test_config_sec.png](images/test_config_sec.png) 
on test ms c ne sauhtentifi pas tt simplemment pcq spring boot attned un mdp hashe 
ya le hashage et lencodage et le cryptage
hashage cad que jai un text et on le donne un algo de hashgae et donne un hash et a parir du hash on peut pas revenir au text orginale et parmi eux on trouve bcrypt qui est for md5 nn c pas fort car on peux revenir au txt porig
encodage passer dun txt a un autre base 64 et paritr du code encode on peux avoir loriginaml 
cryptag il faux un algo de cryptage et une cle de cryptage algo peux etre synetriaue cad celui utilsie en cryptage le meme que cleui du decrypt
ms ya les rsa ou il utilsie une  pair de cle public et prive on crypte avec une cle par expe pub et et on decrypt avec par expe;le la prive 
ms nosu on sinteress que du hachage
![test2_configSec.png](images/test2_configSec.png)
la il nous authenitifie
ces mdp se stocke dans bd ms se son hashe
On essay de suppr un produits la il ne premt pas car nous avons un role user pas admin
![authentif_succes.png](images/authentif_succes.png)
![interdiction.png](images/interdiction.png)
error 403 cad qquon est non auorise a faire cette action al car nosu avons se conencter avec compte user
Logout il existe pas defai dans spring sec il suffit dajout /logout en url
pour se connecter avec le compte dadmin
 ![logout.png](images/logout.png)
on se connecte au admin 
![con_admin.png](images/con_admin.png)
![echec_save.png](images/echec_save.png)
car ca nessecite une authentif avec role admin
La on essaye de suppr et ajoute un m poduit c bon ca marche
Prod ajoute:
![prod_ajoute.png](images/prod_ajoute.png)
Prod Supr:
![prod_supr.png](images/prod_supr.png)
tt necessite auth avec lu role seul /public grace a permit all cad autorise sans authenitf
hasrole necessite authentif aevc un role

on passe a changer dans notre controller par /admin/delet /admin /savre etc
![modif_route.png](images/modif_route.png)

on ajoute namespace sec tehulead extras pour affic he nom user authentif 
![nom_user.png](images/nom_user.png)

ne pas affiche rla page derr 403 c mieux  de le redigier vers une page exececption handling , not authorised
Not authorized paeg jessaye de suppr ca saffiche
![notAuthorized.png](images/notAuthorized.png)
Mainteant on va cacher les btns supprimer et ajouter sur les users 
et lafficher a condition si la security est authorized
via le code sec:authorize="hasRole('ADMIN')"
![cacher_boutton.png](images/cacher_boutton.png)

jessaye de supprimer depuis lurl pour voir si ca marche ou nn 

![essai_supression.png](images/essai_supression.png)
et voila je suis non authorise 
![notAuthorized.png](images/notAuthorized.png)
nous avons essaye avec admin ca marche
ici on utilise la meth dauthentif statefull
ms en authntifiant il renvoie set cookie
spring ssec verifie mdp e cree session t renvoie la session ss forme de cookie  et le browser la sstocke   cote navigatur
son nom c jsession id
httponly cad qu cookie qui ne peux pas etre lit aevc java script
a chaue fosi en envoie un req on envoie uen session id et lui il cherche sil est ouvrerte deja et si jai droit deffceur loperartion ou non
qund vous utilsier les cookies vous etes atcker a lattacke csrf car le num de session est stockes dans les cokies de votre browser ms si un vous envoie un email cliquer pour decouvrir un chose si vosu cliquer vous allz snvoir un req a votre serveur pour fiare une acion non voulu et la le browser renvoie les cookies aussi car il toruve que la session est ouverte
une fosi vous utilsier les cookies vous tes en attques de csrf
et pour corriger ca il faux a caue fois un user demande un form il lenvoie avec un champs cachue qui est csrf token
a chaue fois il ajoute un champos hiden qui est tken pour que server le reccupere dans la session si c le mem il laisse passe sinn il refuse la requette car il va considerer que lqreq provient dune paeg fournit par server ou dun forme non voulu 
spring sec utilise par defaur cette protection par exple si vosu authentif en tq admin et si vous voulez saisir les donnees  si on regde lform cote navigateur on va trouver le csrf token de facon cach mmme si elle nest pas affcieh dans le form je lenvoie avec ms donnees sans savoir pour eviter csrf 
![csrf.png](images/csrf.png)

pour la desctiver on met .csrf.disable()
prq on va la desactiv par exple si on veut utilsie rstateless
la on verifie le cha mos ne reste plus 

ms maintenant on exposer a tt force non voulez par exple suppression non voulu  en cliquent un lien on doit maintenna resoudre ce prob
cad on envoie nos cookie pour suppr sans savoir ca et pour se faire
on doit lactiver avec protection apr defaut 
on reacrive protecion csrf pour le moment et c bon maitnent c protge
avec activer protection aevc defaut 

ms reste prob avec delete  ms delete mapping au lieu de get mapping
c pour cela que aevc dellete il faut jamis utilsier get
c pour cela on doit faire un from avec meth delelte
ms ya pas meth delete on utilsie post
![notauthorized.png](img_1.png)
ca ne pemet pas ca
donc jamais utilsier gt pour save et dlete
car jaurai pu luilser sasn qu je lutilsie post c comme delete 

on cree notre form personnalise dauthtif
via                 .formLogin(fl->fl.loginPage("/login"))
on cree la page de login et on lautorize i avec 
securilty  via permitall sinn il va nmecessit un auth
ms le prob que tu utilsie bbotstrap et tu na pas le droit de lui acceder c pour cela il faut ajout ajouter webjar en permit all
on ajoute le logout pu fermer la session via session ionvalisdate
voila la page login ca marche 
![login.png](images/login.png)
c bon on est en home
on restype le login et c bon
Login style

comemnt protger lapp  
via auhtorzed requst ou pre authorized(has role ) ou enabled
![login_style.png](images/login_style.png)


2 meth pour proter les app : on peux utilsier les deux
authorizehhtp enable ...  ou le annotation dans controller 

si on dmd form c not authorized
image not 
autorize http request cad que vous avez une classe de config ou vous config de securite

    //apres on va lutiliser pas ms on le securise avec json web token et au lieu de ca on utlise user web details
